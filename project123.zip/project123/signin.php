<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="color.css">
    <title>Sign In Page</title>
</head>
<body>
    <div class="container">
        <form id="signInForm">
            <h2>Sign In</h2>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="button" onclick="signIn()">Sign In</button>
        </form>
    </div>

    <script src="script.js"></script>
    <script src="login.js">
</script>
</body>
</html>
