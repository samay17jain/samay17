function signIn() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    // For simplicity, you can add basic validation here

    // In a real-world scenario, you would send this data to a server for authentication
    console.log('Username:', username);
    console.log('Password:', password);
    // Add your authentication logic here

    // For this example, let's just display an alert
    alert('Sign in successful!');
}
