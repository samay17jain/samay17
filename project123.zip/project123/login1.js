function validateForm() {
    var username = document.getElementById('username').value;
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;

    // Simple validation
    if (username.trim() === '' || email.trim() === '' || password.trim() === '') {
        alert('Please fill in all fields');
    } else {
        alert('Sign up successful!\nUsername: ' + username + '\nEmail: ' + email);
        // Here you can send the form data to the server for further processing
    }
}
